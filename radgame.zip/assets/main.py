import pygame, asyncio
from sys import exit
from random import randint, uniform
from xapi import send_xapi_statement
import time

# Player Info Collection Screen
def collect_player_info():
    global player_name, player_email, player_profession
    
    input_name = ""
    input_email = ""
    input_profession = ""
    
    current_input = "name"  # Options: "name", "email", "profession"
    collecting_info = True
    
    # Text input surfaces
    input_font = pygame.font.Font('font/Pixeltype.ttf', 35)
    title_font = pygame.font.Font('font/Pixeltype.ttf', 50)
    
    while collecting_info:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
                
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    if current_input == "name" and input_name:
                        current_input = "email"
                    elif current_input == "email" and input_email:
                        current_input = "profession"
                    elif current_input == "profession" and input_profession:
                        player_name = input_name
                        player_email = input_email
                        player_profession = input_profession
                        collecting_info = False
                elif event.key == pygame.K_BACKSPACE:
                    if current_input == "name":
                        input_name = input_name[:-1]
                    elif current_input == "email":
                        input_email = input_email[:-1]
                    else:
                        input_profession = input_profession[:-1]
                else:
                    if current_input == "name":
                        if len(input_name) < 20:  # Limit name length
                            input_name += event.unicode
                    elif current_input == "email":
                        if len(input_email) < 30:  # Limit email length
                            input_email += event.unicode
                    else:
                        if len(input_profession) < 30:  # Limit profession length
                            input_profession += event.unicode
        
        # Drawing
        screen.fill((94, 129, 162))
        
        # Title
        title_text = title_font.render("Player Information", True, (255, 255, 255))
        screen.blit(title_text, title_text.get_rect(center=(600, 100)))
        
        # Name input
        name_label = input_font.render("Name:", True, (255, 255, 255))
        name_input = input_font.render(input_name, True, (255, 255, 255))
        name_rect = pygame.Rect(400, 200, 400, 50)
        pygame.draw.rect(screen, (50, 50, 50), name_rect, 0 if current_input == "name" else 1)
        screen.blit(name_label, (300, 200))
        screen.blit(name_input, (name_rect.x + 10, name_rect.y + 10))
        
        # Email input
        email_label = input_font.render("Email:", True, (255, 255, 255))
        email_input = input_font.render(input_email, True, (255, 255, 255))
        email_rect = pygame.Rect(400, 280, 400, 50)
        pygame.draw.rect(screen, (50, 50, 50), email_rect, 0 if current_input == "email" else 1)
        screen.blit(email_label, (300, 280))
        screen.blit(email_input, (email_rect.x + 10, email_rect.y + 10))
        
        # Profession input
        prof_label = input_font.render("Profession:", True, (255, 255, 255))
        prof_input = input_font.render(input_profession, True, (255, 255, 255))
        prof_rect = pygame.Rect(400, 360, 400, 50)
        pygame.draw.rect(screen, (50, 50, 50), prof_rect, 0 if current_input == "profession" else 1)
        screen.blit(prof_label, (250, 360))
        screen.blit(prof_input, (prof_rect.x + 10, prof_rect.y + 10))
        
        # Instructions
        instruction_text = input_font.render("Press ENTER to continue", True, (255, 255, 255))
        screen.blit(instruction_text, instruction_text.get_rect(center=(600, 450)))
        
        pygame.display.update()
        clock.tick(60)
    
    return player_name, player_email, player_profession

# Player with dynamically settable radiation reading
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.base_image = pygame.image.load('graphics/Geiger/easy.png').convert_alpha()
        self.image = self.base_image.copy()
        self.rect = self.image.get_rect(midbottom=(150, 500))
        self.current_reading = None

    def set_reading(self, value):
        self.current_reading = value
        self.image = self.base_image.copy()
        font = pygame.font.Font('font/Pixeltype.ttf', 30)
        reading_text = font.render(f"{value:.2f}", True, (255, 0, 0))
        text_x = 30
        text_y = 70
        self.image.blit(reading_text, (text_x, text_y))

    def update(self):
        pass

# Obstacle with ti_num and surface_num
class Obstacle(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load('graphics/Package/radpack.png').convert_alpha()
        self.rect = self.image.get_rect(midbottom=(randint(1150, 1250), 500))

        self.ti_num = round(uniform(0, 10), 1)
        self.surface_num = None

    def update(self):
        self.rect.x -= 6
        self.destroy()

    def destroy(self):
        if self.rect.x <= -100:
            self.kill()

def display_score(score):
    score_surf = test_font.render(f'Score: {score}', False, (64, 64, 64))
    score_rect = score_surf.get_rect(center=(600, 50))  # Centered horizontally
    screen.blit(score_surf, score_rect)

def display_ti_index(ti_value):
    # TI Index
    ti_surf = test_font.render(f'TI Index: {ti_value:.2f} mR/hr', False, (255, 0, 0))
    ti_rect = ti_surf.get_rect(topright=(1150, 20))  # Top-right corner
    screen.blit(ti_surf, ti_rect)

    # Background radiation
    bg_surf = test_font.render(f"Background: {background_num:.2f} mR/hr", False, (255, 0, 0))
    bg_rect = bg_surf.get_rect(topright=(1150, ti_rect.bottom + 10))
    screen.blit(bg_surf, bg_rect)

def draw_game():
    screen.blit(sky_surface, (0, 0))
    screen.blit(ground_surface, (0, 500))
    for i, img in enumerate(key_images):
        pos_x = 300 + i * 150
        pos_y = 100
        if highlighted_key == i:
            pygame.draw.rect(screen, (255, 255, 0), (pos_x - 5, pos_y - 5, img.get_width() + 10, img.get_height() + 10), 3)
        screen.blit(img, (pos_x, pos_y))

    display_score(score)
    player.draw(screen)
    player.update()
    obstacle_group.draw(screen)
    obstacle_group.update()

def collision_sprite():
    return pygame.sprite.spritecollide(player.sprite, obstacle_group, False)

def get_correct_key(ti, surface):
    net_ti = ti - background_num
    net_surface = surface - background_num

    if net_ti == 0 and net_surface == 0:
        return 0
    elif net_ti == 0 and net_surface <= 0.5:
        return 1
    elif 0 < net_ti < 1 and 0.5 < net_surface < 50:
        return 2
    elif 1 <= net_ti < 10 and 50 < net_surface < 200:
        return 3
    else:
        return None

def reset_game():
    global game_active, paused, game_over, show_result, result_message, score, highlighted_key, background_num, game_start_time, session_count
    if game_over:  # Track replay only if coming from a finished game
        session_count += 1
        # Send xAPI statement for game replay
        send_xapi_statement(
            name=player_name,
            email=player_email,
            verb_display="restarted",
            verb_id="http://adlnet.gov/expapi/verbs/restarted",
            object_display="Radiation Game Session",
            object_id="https://hyeinhaley.github.io/radiation-game/session",
            extensions={
                "https://example.com/session": session_count,
                "https://example.com/previous_score": score
            }
        )
    
    game_active = True
    paused = False
    game_over = False
    show_result = False
    result_message = None
    score = 0
    highlighted_key = None
    obstacle_group.empty()
    player_sprite.set_reading(0.00)
    game_start_time = time.time()
    
    # Background radiation is between 0 and 0.07 mR/hr
    background_num = round(uniform(0, 0.07), 2)

# xAPI helper functions
def send_package_interaction(ti_num, surface_num, correct_key, player_key, is_correct):
    """Send xAPI statement for a package interaction with readable summary"""
    result_text = "correct" if is_correct else "incorrect"

    readable_summary = (
        f"ti_num: {ti_num:.2f}, "
        f"surface_num: {surface_num:.2f}, "
        f"correct_key: {correct_key}, "
        f"player answer: {result_text}"
    )

    send_xapi_statement(
        name=player_name,
        email=player_email,
        verb_display="answered",
        verb_id="http://adlnet.gov/expapi/verbs/answered",
        object_display="Package Classification Question",
        object_id="https://hyeinhaley.github.io/radiation-game/package-interaction",
        result={
            "success": is_correct,
            "score": {
                "raw": 1 if is_correct else 0,
                "min": 0,
                "max": 1
            }
        },
        extensions={
            "https://example.com/ti_num": ti_num,
            "https://example.com/surface_num": surface_num,
            "https://example.com/correct_key": correct_key,
            "https://example.com/player_answer": player_key,
            "https://example.com/result": result_text,
            "https://example.com/background": background_num
        },
        description_override=readable_summary  # 👈 pass the readable format
    )


def send_game_end(final_score, duration):
    """Send xAPI statement for game end"""
    send_xapi_statement(
        name=player_name,
        email=player_email,
        verb_display="completed",
        verb_id="http://adlnet.gov/expapi/verbs/completed",
        object_display="Radiation Game Session",
        object_id="https://hyeinhaley.github.io/radiation-game/session",
        result={
            "score": {
                "raw": final_score,
                "min": 0
            },
            "completion": True
        },
        extensions={
            "https://example.com/session": session_count,
            "https://example.com/duration_seconds": round(duration, 2)
        }
    )

# Initialize player info variables
player_name = ""
player_email = ""
player_profession = ""

# Send xAPI statement for game start
def send_game_start():
    send_xapi_statement(
        name=player_name,
        email=player_email,
        verb_display="launched",
        verb_id="http://adlnet.gov/expapi/verbs/launched",
        object_display="Radiation Game Session",
        object_id="https://hyeinhaley.github.io/radiation-game/session",
        extensions={
            "https://example.com/profession": player_profession,
            "https://example.com/session": session_count,
            "https://example.com/background_radiation": background_num
        }
    )

# Pygame setup
pygame.init()
screen = pygame.display.set_mode((1200, 600))
pygame.display.set_caption('Radioactive Package Game')
clock = pygame.time.Clock()
test_font = pygame.font.Font('font/Pixeltype.ttf', 45)

# Load symbol image for title screen and game over screen
symbol_image = pygame.image.load('graphics/symbol.png').convert_alpha()
symbol_rect = symbol_image.get_rect(center=(600, 300))  # Position below text

game_active = False
paused = False
game_over = False
score = 0
background_num = round(uniform(0, 0.07), 2)
bg_music = pygame.mixer.Sound('audio/music.mp3')
bg_music.play(loops=-1)

# Game session tracking
game_start_time = time.time()
session_count = 1
has_sent_start = False
player_info_collected = False

player = pygame.sprite.GroupSingle()
player_sprite = Player()
player.add(player_sprite)

obstacle_group = pygame.sprite.Group()

sky_surface = pygame.transform.scale(pygame.image.load('graphics/Sky.png').convert(), (1200, 600))
ground_surface = pygame.transform.scale(pygame.image.load('graphics/ground.png').convert(), (1200, 100))

game_name = test_font.render('Radioactive Package Game', False, (111, 196, 169))
game_name_rect = game_name.get_rect(center=(600, 120))  # Keeping centered horizontally

game_message = test_font.render('Press space to run', False, (111, 196, 169))
game_message_rect = game_message.get_rect(center=(600, 450))  # Keeping centered horizontally

obstacle_timer = pygame.USEREVENT + 1
pygame.time.set_timer(obstacle_timer, 1500)

key_images = [pygame.image.load(f'graphics/keys/{i}.png').convert_alpha() for i in range(4)]
highlighted_key = None
collided_obstacle = None
correct_key = None

result_message = None
result_timer = 0
show_result = False

# Collect player info first
if not player_info_collected:
    player_name, player_email, player_profession = collect_player_info()
    player_info_collected = True
    print(f"Player info collected: {player_name}, {player_email}, {player_profession}")

async def main():

    # Game loop
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Send final stats before quitting if game was active
                if game_active:
                    game_duration = time.time() - game_start_time
                    send_game_end(score, game_duration)
                pygame.quit()
                exit()
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if not game_active:
                        reset_game()
                        # Track game start with xAPI
                        if not has_sent_start:
                            send_game_start()
                            has_sent_start = True
                        
                elif paused and event.key in (pygame.K_0, pygame.K_1, pygame.K_2, pygame.K_3):
                    pressed_key = int(event.key - pygame.K_0)
                    is_correct = pressed_key == correct_key
                    
                    if is_correct:
                        result_message = "Correct!"
                        score += 1
                    else:
                        result_message = "Incorrect!"
                        game_over = True
                    
                    # Send xAPI about this package interaction
                    send_package_interaction(
                        ti_num=collided_obstacle.ti_num,
                        surface_num=collided_obstacle.surface_num,
                        correct_key=correct_key,
                        player_key=pressed_key,
                        is_correct=is_correct
                    )
                    
                    # If game over, send final stats
                    if game_over:
                        game_duration = time.time() - game_start_time
                        send_game_end(score, game_duration)
                    
                    result_timer = pygame.time.get_ticks()
                    show_result = True
                    obstacle_group.empty()
                
                elif game_active and not paused and event.key in (pygame.K_0, pygame.K_1, pygame.K_2, pygame.K_3):
                    highlighted_key = int(event.key - pygame.K_0)

            if game_active and not paused and event.type == obstacle_timer:
                if len(obstacle_group) == 0:
                    new_obstacle = Obstacle()
                    obstacle_group.add(new_obstacle)
                    collided_obstacle = new_obstacle
                    import random
                    target_key = random.choice([0, 1, 2, 3])

                    # For all cases, background_num is between 0 and 0.07
                    if target_key == 0:
                        # Case 0: ti_num equals background_num (0-0.07)
                        collided_obstacle.ti_num = background_num
                        collided_obstacle.surface_num = background_num
                        correct_key = 0

                    elif target_key == 1:
                        # Case 1: ti_num equals background_num, surface slightly higher
                        collided_obstacle.ti_num = background_num
                        collided_obstacle.surface_num = round(background_num + uniform(0.01, 0.5), 2)
                        correct_key = 1

                    elif target_key == 2:
                        # Case 2: ti_num slightly above background, surface moderately higher
                        collided_obstacle.ti_num = round(background_num + uniform(0.01, 0.99), 3)
                        collided_obstacle.surface_num = round(background_num + uniform(0.51, 49.99), 2)
                        correct_key = 2

                    elif target_key == 3:
                        # Case 3: ti_num significantly above background, surface much higher
                        collided_obstacle.ti_num = round(background_num + uniform(1.01, 9.9), 2)
                        collided_obstacle.surface_num = round(background_num + uniform(50.01, 199.99), 2)
                        correct_key = 3

                    player_sprite.set_reading(collided_obstacle.ti_num)

        if game_active:
            screen.blit(sky_surface, (0, 0))
            screen.blit(ground_surface, (0, 500))
            for i, img in enumerate(key_images):
                pos_x = 300 + i * 150
                pos_y = 100
                if highlighted_key == i:
                    pygame.draw.rect(screen, (255, 255, 0), (pos_x - 5, pos_y - 5, img.get_width() + 10, img.get_height() + 10), 3)
                screen.blit(img, (pos_x, pos_y))

            if not paused:
                display_score(score)
                player.draw(screen)
                player.update()
                obstacle_group.draw(screen)
                obstacle_group.update()
                if collision_sprite():
                    paused = True
                    collided_obstacle = obstacle_group.sprites()[0]
                    player_sprite.set_reading(collided_obstacle.surface_num)
                    print(f"📦 ti_num: {collided_obstacle.ti_num:.2f}, surface_num: {collided_obstacle.surface_num:.2f}, correct_key: {correct_key}")

            else:
                player.draw(screen)
                obstacle_group.draw(screen)
                if collided_obstacle:
                    display_ti_index(collided_obstacle.ti_num)
                if result_message:
                    color = (0, 255, 0) if result_message == "Correct!" else (255, 0, 0)
                    pause_text = test_font.render(result_message, True, color)
                else:
                    pause_text = test_font.render('Collision! Press 0, 1, 2, or 3 to continue.', False, (255, 0, 0))
                screen.blit(pause_text, pause_text.get_rect(center=(400, 50)))
        else:
            screen.fill((94, 129, 162))
            obstacle_group.empty()
            
            # Display package image
            screen.blit(symbol_image, symbol_rect)
            
            score_message = test_font.render(f'Your score: {score}', False, (111, 196, 169))
            score_message_rect = score_message.get_rect(center=(600, 500))  # Keeping centered horizontally
            game_over_message = test_font.render('Game Over! Press space to restart.', False, (111, 196, 169))
            game_over_message_rect = game_over_message.get_rect(center=(600, 450))  # Keeping centered horizontally
            screen.blit(game_name, game_name_rect)
            if score:
                screen.blit(game_over_message, game_over_message_rect)
                screen.blit(score_message, score_message_rect)
            else:
                screen.blit(game_message, game_message_rect)

        # ✅ Show correct/incorrect result for 2 seconds
        if show_result and pygame.time.get_ticks() - result_timer >= 500:
            result_message = None
            show_result = False
            if not game_over:
                paused = False
            else:
                game_active = False

        pygame.display.update()
        clock.tick(60)
        await asyncio.sleep(0)
        
asyncio.run(main())