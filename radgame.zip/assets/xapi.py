import requests
import base64
import datetime
import json

LRS_ENDPOINT = "https://radsafe.lrs.io/xapi/statements/"
USERNAME = "bewnuz"
PASSWORD = "vibvof"

def send_xapi_statement(name, email, verb_display, verb_id, object_display, object_id,
                        result=None, extensions=None, description_override=None):
    timestamp = datetime.datetime.utcnow().isoformat() + "Z"
    
    # Ensure email is properly formatted
    if "@" in email and "." not in email.split("@")[1]:
        email += ".com"
    
    # Authentication header
    auth_string = f"{USERNAME}:{PASSWORD}"
    auth_encoded = base64.b64encode(auth_string.encode()).decode()
    headers = {
        "X-Experience-API-Version": "1.0.3",
        "Authorization": f"Basic {auth_encoded}",
        "Content-Type": "application/json"
    }
    
    # Use custom description if provided
    description = description_override or "Radiation Safety Game Activity"
    
    # Build xAPI statement
    data = {
        "actor": {
            "name": name,
            "mbox": f"mailto:{email}",
            "objectType": "Agent"
        },
        "verb": {
            "id": verb_id,
            "display": {"en-US": verb_display}
        },
        "object": {
            "id": object_id,
            "definition": {
                "name": {"en-US": object_display},
                "type": "http://adlnet.gov/expapi/activities/simulation",
                "description": {"en-US": description}
            },
            "objectType": "Activity"
        },
        "timestamp": timestamp
    }
    
    if result:
        data["result"] = result
    
    if extensions:
        data.setdefault("context", {}).setdefault("extensions", {}).update(extensions)
    
    try:
        print("Sending xAPI statement:", json.dumps(data, indent=2))
        print("To endpoint:", LRS_ENDPOINT)
        print("With headers:", headers)
        response = requests.post(LRS_ENDPOINT, headers=headers, json=data)
        print("Response status code:", response.status_code)
        print("Response headers:", response.headers)
        print("Response content:", response.text)
        response.raise_for_status()
        print("✅ xAPI statement sent successfully.")
        return True
    except requests.exceptions.RequestException as e:
        print(f"❌ xAPI Error: {type(e).__name__}: {e}")
        return False

# Example testing block with user input
if __name__ == "__main__":
    # Get user input instead of hardcoded values
    user_name = input("Enter user name: ")
    user_email = input("Enter user email: ")
    
    summary = "ti_num: 3.54, surface_num: 119.63, correct_key: 3, player answer: correct"
    success = send_xapi_statement(
        name=user_name,
        email=user_email,
        verb_display="answered",
        verb_id="http://adlnet.gov/expapi/verbs/answered",
        object_display="Package Classification Question",
        object_id="https://hyeinhaley.github.io/radiation-game/package-interaction",
        result={
            "success": True,
            "score": {"raw": 1, "min": 0, "max": 1}
        },
        extensions={
            "https://example.com/ti_num": 3.54,
            "https://example.com/surface_num": 119.63,
            "https://example.com/correct_key": 3,
            "https://example.com/player_answer": 3,
            "https://example.com/result": "correct",
            "https://example.com/background": 0.01
        },
        description_override=summary
    )
    print(f"Statement sending was {'successful' if success else 'unsuccessful'}")